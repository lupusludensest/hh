from selenium import webdriver


capabilities = {
    "browserName": "chrome",
    "version": "89.0",
    "enableVNC": True,
    "enableVideo": False,
}

driver = webdriver.Remote(
    command_executor="http://localhost:4444/wd/hub",
    desired_capabilities=capabilities)
